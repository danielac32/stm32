# CLox Interpreter

This is an implementation of the CLox interpreter implemented in the second part of the book
[crafting interpreters](https://www.craftinginterpreters.com/).

This is a work-in-progress and might deviate from the original implementation in some parts.
