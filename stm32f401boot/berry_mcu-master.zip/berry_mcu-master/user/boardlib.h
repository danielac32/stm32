#ifndef __BOARDLIB_H
#define __BOARDLIB_H

#include "berry.h"

void board_init(void);

#endif
