#ifndef __SHELL_H
#define __SHELL_H

int shell_addchar(int ch);
const char* shell_readline(const char *prompt);

#endif
