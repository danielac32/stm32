win('r')
wait(200)
typeln('https://i.imgflip.com/5cb0aj.png')

