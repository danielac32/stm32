typeln('Hello, world!')
mouseMove(20, 20)
