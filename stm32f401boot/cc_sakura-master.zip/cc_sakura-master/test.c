int main(void){
    int x = -1;

    if (x == -1) {
        return 0;
    }

    return 1;
}

