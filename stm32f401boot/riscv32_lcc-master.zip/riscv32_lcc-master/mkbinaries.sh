cd binutils
make install
cd ../lcc
make all
cd ..