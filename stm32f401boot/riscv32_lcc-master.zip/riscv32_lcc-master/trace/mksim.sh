iverilog -o simv -c args.f -D MEM_FILENAME=\"$1.hex\"

