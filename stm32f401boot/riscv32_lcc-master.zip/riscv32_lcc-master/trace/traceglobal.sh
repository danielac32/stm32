./mkfw.sh global
./mksim.sh global
./simv +vcd
python3 trace.py global






