iverilog -o simv -c args.f -D MEM_FILENAME=\"firmware.mem\"

