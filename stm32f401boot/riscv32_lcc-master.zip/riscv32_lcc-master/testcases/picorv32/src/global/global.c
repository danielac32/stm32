int x;
int y;

int main()
{
  int a;
  a = 33;
  x = a;
  y = x;
  a = x + y;
  puti(a);
  putc('\n');
  return 0;
}
