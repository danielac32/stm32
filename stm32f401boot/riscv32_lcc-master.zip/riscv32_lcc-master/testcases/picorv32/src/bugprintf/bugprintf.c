#include <stdio.h>


int main(void) {
  printf("Hi %d, %d, %d, %d\n", 1 , 2, 3, 4); 
  return 0;
}
