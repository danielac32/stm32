#include <stdio.h>

int main(void) {
  printf("sqrt(3)= %2.4f\n",sqrt(3.0));
  return 0;
}
