python3 debug.py main





