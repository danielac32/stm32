
 VM with a Mini Language:

 COMPILE:
   make clean
   make

 TESTING:
   mini
   or
   mini -d
   or
   mini test.s
   mini function.s

 BY: Francisco - gokernel@hotmail.com
