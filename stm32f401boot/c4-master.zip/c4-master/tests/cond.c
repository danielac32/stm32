int main(int argc, char **argv) {
    if (argc == 1) { printf("Usage: <me> <gibberish>\n"); }
    else { printf("argc = %d\n", argc); }
    return 0;
}
