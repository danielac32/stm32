Bienvenido a la wiki de Berry!
==============================

.. toctree::
   :hidden:
   
   Manual de referencia del lenguaje Berry Script <Referencia>
   FFI-Ejemplo <FFI-Ejemplo>
   Hoja de ruta <Hoja-de-ruta>
   Requerimientos de Memoria <Requerimientos-de-Memoria>
