#!/usr/bin/env bash

sudo apt-get install -y libreadline-dev
make
